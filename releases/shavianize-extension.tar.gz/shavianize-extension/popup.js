var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

// src/popup.ts
var popup_default = undefined;
export {
  popup_default as default
};
