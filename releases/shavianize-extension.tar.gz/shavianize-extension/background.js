var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

// src/background.ts
var background_default = undefined;
export {
  background_default as default
};
